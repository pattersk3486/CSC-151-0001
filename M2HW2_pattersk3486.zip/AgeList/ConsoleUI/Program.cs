﻿//2/17/19
//CSC 153
//Kevin Patterson
//Ages

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        { string userInput;
          int numberOfAges;
            List<int> ages = new List<int>();
            int age;
            Console.WriteLine("1.Run the Program\n2.Exit");
            userInput = Console.ReadLine();
            if (userInput == "1")
            {
                Console.WriteLine("Enter the number of ages");
                userInput = Console.ReadLine();
                int.TryParse(userInput, out numberOfAges);
                for (int i = 0; i < numberOfAges; i++)
                {
                    Console.WriteLine("Enter an age: ");
                    userInput = Console.ReadLine();
                    int.TryParse(userInput, out age );
                    ages.Add(age);
                    ages.Average();
                }
                Console.WriteLine(ages);
            }
        }
    }
}
