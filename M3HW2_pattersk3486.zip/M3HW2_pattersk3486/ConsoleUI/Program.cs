﻿//Kevin Patterson
//2/25/20
//CSC 151
//Falling Distance
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            
            double time;
            double meters;
            Console.WriteLine("Please enter the time in seconds: ");
            Double.TryParse(Console.ReadLine(), out time);
            meters = FallingDistance(time);
            Console.WriteLine($"This object fell {meters} meters");
            Console.ReadLine();

        }
        public static double FallingDistance(double time)
        {
            double g = 9.8;
            

            return (time * time) * (9.8) * .5; 
        }
    }   
}
