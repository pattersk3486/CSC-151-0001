﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class EmployeeClass

    { private class Employee
        {  //Fields
            private string _employeename;
            private string _employeephone;
            private int _employeeage;

            //TODO Constructor
            public Employee()
            {
                Name = "";
                Phone = "";
                Age = 0;
            }
            public Employee (string name, string phone, int age)
            {
                Name = name;
                Phone = phone;
                Age = 0;
            }
            public string Name
            {
                get
                {
                    return _employeename;
                }
                set
                {
                    _employeename = value;
                }

            }
            public string Phone
            {
                get
                {
                    return _employeephone;
                }
                set
                {
                    _employeephone = value;
                }
            }
            public int Age
            {
                get
                {
                    return _employeeage;
                }
                set
                {
                    _employeeage = value;
                }
            }
            

        }
    }
}
