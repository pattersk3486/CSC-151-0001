﻿  //2/21/20
  //CSC 153
  //Kevin Patterson
  //Text Adventure
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            bool exit = false;
            string[] rooms = { "Entrance", "Hallway", "Office", "Basement", "Stairwell" };
            string[] weapons = { "Handgun", "Lead pipe", "Combat Knife", "Rifle" };
            string[] potions = { "Medkit", "Painkillers" };
            string[] treasures = { "Treasured Katana", "Treasured Magnum", "Treasured Knife" };
            List<string> items = new List<string>() { "10x 9mm Ammo", "10x .556 Hollowpoint Rifle Ammo", "Poison Gel", "Unknown metal" };
            List<string> mobs = new List<string>() { "Crazed Bandit", "Maurader", "Shuffling Corpse", "Lengndary Theif", "Fatman" };
            
                Console.WriteLine("1.Display Rooms");
                Console.WriteLine("2.Display Weapon");
                Console.WriteLine("3.Display Potion");
                Console.WriteLine("4.Display Treasure");
                Console.WriteLine("5.Display Items");
                Console.WriteLine("6.Display Mobs");
                Console.WriteLine("7.Exit");
                input = Console.ReadLine();
            if (input == "1")
            {
                foreach (string i in rooms)
                {
                    Console.WriteLine(i);
                    
                }
            }
            if (input == "2")
            {
                foreach (string i in weapons)
                {
                    Console.WriteLine(i);
                    
                }
            }
            if (input == "3")
            {
                foreach (string i in potions)
                {
                    Console.WriteLine(i);
                    
                }
            }
            if (input == "4")
            {
                foreach (string i in treasures)
                {
                    Console.WriteLine(i);
                    
                }
            }
            if (input == "5")
            {
                foreach (string i in items)
                {
                    Console.WriteLine(i);

                }
            }
            if (input == "6")
            {
                foreach (string i in mobs)
                {
                    Console.WriteLine(i);

                }
            }
            if (input == "7")
            {
                System.Environment.Exit(0);
            }

            Console.ReadLine();


        }
    }
}
