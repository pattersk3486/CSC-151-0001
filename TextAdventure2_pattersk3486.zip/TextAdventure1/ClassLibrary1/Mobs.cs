﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ClassLibrary1
//{
//    public class Mob
//    {
//        //Fields
//        private string _MobName;
       

//        //Constructor
//        public Mob()
//        {
//            MobName = "";
//            HP = 0;

//        }
//        public Mob(string MobName, int health)
//        {
//            MobName = mobName;
//            HP = health;
//        }
//        //Full Property
//        public string MobName
//        {
//            get
//            {
//                return _mobName;
//            }
//            set
//            {
//                _mobName = value;
//            }
//        }
//        //Auto Property
//        public int HP { get; set; }

//        //Methods
//        public int DoMath()
//        {
//            return 4 + 5;
//        }
//        public int DoMath(int value1, int value2)
//        {
//            return value1 + value2;
//        }
//    }

//}

