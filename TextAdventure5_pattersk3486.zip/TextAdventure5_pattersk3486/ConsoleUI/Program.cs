﻿/**

* 5/10/20

* CSC 153

* Kevin Patterson

* Text Adventure

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            bool exit = false;
            string[] rooms = { "Entrance", "Hallway", "Office", "Basement", "Stairwell" };
            string[] weapons = { "Handgun", "Lead pipe", "Combat Knife", "Rifle" };
            string[] potions = { "Medkit", "Painkillers" };
            string[] treasures = { "Treasured Katana", "Treasured Magnum", "Treasured Knife" };
            List<string> items = new List<string>() { "10x 9mm Ammo", "10x .556 Hollowpoint Rifle Ammo", "Poison Gel", "Unknown metal" };
            List<string> mobs = new List<string>() { "Crazed Bandit", "Marauder", "Shuffling Corpse", "Legendary Thief", "Fatman" };
            
            do
            {
                Console.WriteLine("1.Display Rooms");
                Console.WriteLine("2.Display Weapon");
                Console.WriteLine("3.Display Potion");
                Console.WriteLine("4.Display Treasure");
                Console.WriteLine("5.Display Items");
                Console.WriteLine("6.Display Mobs");
                Console.WriteLine("7.Exit");
                input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        foreach (string i in rooms)
                        {
                            Console.WriteLine(i);

                        }
                        break;
                    case "2":
                        foreach (string i in weapons)
                        {
                            Console.WriteLine(i);

                        }
                        break;
                    case "3":
                        foreach (string i in potions)
                        {
                            Console.WriteLine(i);

                        }
                        break;
                    case "4":
                        foreach (string i in treasures)
                        {
                            Console.WriteLine(i);

                        }
                        break;
                    case "5":
                        foreach (string i in items)
                        {
                            Console.WriteLine(i);

                        }
                        break;
                    case "6":
                        foreach (string i in mobs)
                        {
                            Console.WriteLine(i);

                        }
                        break;
                    case "7":
                        {
                            exit = true;
                            break;
                        }
                    default:
                        Console.WriteLine("Not a valid choice!");
                        Console.WriteLine();
                        break;

                }
            } while (exit == false);
            MoveMenu();

        }
        public static void MoveMenu()
        {
            string input;
            bool exit = false;
            int roomNumber = 0;
            string[] rooms = { "Entrance", "Hallway", "Office", "Basement", "Stairwell" };
            do
            {
                Console.WriteLine("1. Move North");
                Console.WriteLine("2. Move South");
                Console.WriteLine("3. Attack");
                Console.WriteLine("4. Exit");
                Console.Write("-->");
                input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                    case "north":
                    case "n":
                        roomNumber++;
                        
                        if (roomNumber > 4)
                        {
                            roomNumber++;
                            roomNumber--;
                            Console.WriteLine("You can't go any further north.");                           
                            break;
                        }
                        else
                        {
                            Console.WriteLine("You went north.");
                            Console.WriteLine($"you are in {rooms[roomNumber]}");
                            break;
                        }
                    case "2":
                    case "south":
                    case "s":
                        
                        roomNumber--;
                        if (roomNumber < 0 )
                        {
                            roomNumber--;
                            roomNumber++;
                            Console.WriteLine("You can't go any further south.");
                            break;
                        }
                        else
                        {
                            roomNumber--;
                            roomNumber++;
                            Console.WriteLine("You went south.");
                            Console.WriteLine($"you are in {rooms[roomNumber]}");
                            break;
                        }
                    case "3":
                    case "attack":
                        {
                            Console.WriteLine(Prompts.StandardMessages.Attack());

                            break;
                        }
                    case "4":
                    case "exit":
                        {
                            exit = true;
                            break;
                        }
                    default:
                        Console.WriteLine("Not a valid choice!");
                        Console.WriteLine();
                        break;
                }
            } while (exit == false);

           



            
            //return MoveMenu();
        }
    }
}
