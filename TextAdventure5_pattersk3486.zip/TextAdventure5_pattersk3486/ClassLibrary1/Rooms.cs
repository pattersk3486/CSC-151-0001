﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Rooms
    {//Fields
        private string _entrance;
        private string _hallway;
        private string _office;
        private string _basement;
        private string _stairwell;
        private string _description;
    }
    //Constructors
    public Rooms()
    {
        Entrance = "";
        Hallway = "";
        Office = "";
        Basement = "";
        Stairwell = "";
        Description = "";
    }
    public Rooms (string entrance, string hallway, string office, string basement, string stairwell, string description)
        {
            Entrance = entrance;
            Hallway = hallway;
            Office = office;
            Basement = basement;
            Stairwell = stairwell;
            Description = description;
        }
    //Full Property
    public string Entrance
    {
        get
        {
            return _entrance;
        }
        set
        {
            _entrance = value;
        }
    }
    public string Hallway
    {
        get
        {
            return _hallway;
        }
        set
        {
            _hallway = value;
        }
    }


}
