﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kevin Patterson
//2/5/20
namespace Employees
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstName;//declare first name variable 
            string phoneNumber;//declare phone number variable
            string age;// declare age variable
            int average;
            System.Console.Write("Enter the employee's first name: ");//ask the user for first name
            firstName = System.Console.ReadLine();//code for input statement           
            System.Console.Write("Enter the employee's phone number: ");//ask user for phone number
            phoneNumber = System.Console.ReadLine();//code for input statement
            System.Console.Write("Enter the employee's age: ");//ask user for age
            age = System.Console.ReadLine();//code for input statement
            System.Console.WriteLine(
                $"Hello, the employee's name is { firstName }, their phone number is { phoneNumber }, and their age is { age }. ");//code for displaying the inputs
            average = 
            System.Console.WriteLine("The average age is" { average });
            
            string[] names;//Array declaration
            string[] name = { firstName };//the 5 elements
            List<string> list = new List<string>();
            list.Add(age);
            list.Add(age);
            list.Add(age);
            list.Add(age);
            list.Add(age);

            System.Console.ReadLine();//display the inputs
        }
    }
}
