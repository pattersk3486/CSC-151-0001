﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryRetailItem
{
    public class RetailItem
    {   //Fields
        private string _description;
        private int _unitsonhand;
        private int _price;
        //TODO Constructor
        
        public RetailItem()
        {
           
            Description = "";
            UnitsOnHand = 0;
            Price = 0;

        }
        public RetailItem(string description, int unitsonhand, int price)
        {
            
            Description = description;
            UnitsOnHand = 0;
            Price = 0;
        }
        //Properties
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        public int UnitsOnHand
        {
            get
            {
                return _unitsonhand;
            }
            set
            {
                _unitsonhand = value;
            }
        }
        public int Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }

    }
}
