﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryRetailItem;
/**
* 3/30/2020
* CSC 153
* Kevin Patterson
* Program description
*/
namespace ConsoleUI
{   
    class Program
    {
        List<string> retailitem = new List<RetailItem>;
        static void Main(string[] args)
        { 
            //ClassLibraryRetailItem.RetailItem;

        }
    }
}
