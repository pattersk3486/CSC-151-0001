﻿//Kevin Patterson
//CSC 153
//2/26/20
//Employees Test
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {//create input var for user input and sentury for loop
            string input;
            bool exit = false;
            //create constant var
            const int SIZE = 5;
            int nameIndex = 0, phoneIndex = 0;
            string[] employeeName = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();
            public static string Menu()
            {

            
            do
            {
                Console.WriteLine("1. Enter employee's name");
                Console.WriteLine("2. Enter employee's phone number");
                Console.WriteLine("3.Enter employee's age");
                Console.WriteLine("4. Display employee information ");
                Console.WriteLine("5. Display average age of employees");
                Console.WriteLine("6. Exit");
                Console.Write("-->");
                input = Console.ReadLine();
                    //Switch to direct to propper process


                    switch (input)

                    {
                        case "1":
                            Console.Write("Enter employee's name -->");
                            input = Console.ReadLine();
                            employeeName[nameIndex] = input;
                            nameIndex++;
                            Console.WriteLine();
                            break;
                        case "2":
                            Console.Write("Enter employee's phone number -->");
                            input = Console.ReadLine();
                            employeeName[phoneIndex] = input;
                            nameIndex++;
                            Console.WriteLine();
                            break;
                        case "3":
                            int number = 0;
                            Console.Write("Enter employee's age -->");
                            input = Console.ReadLine();
                            if (int.TryParse(input, out number))
                            {
                                employeeAge.Add(number);
                            }
                            else
                            {
                                Console.WriteLine("Not a valid number!");
                            }
                            Console.WriteLine();
                            break;
                        case "4":
                            // We use the Count methode of the list since will
                            //may not have as
                            // may element as the arrays
                            for (int index = 0; index < employeeAge.Count; index++)
                            {
                                Console.WriteLine($"Employee Name- {employeeName[index]}");
                                Console.WriteLine($"Employee Phone- {employeePhone[index]}");
                                Console.WriteLine($"Employee Age- {employeeAge[index]}");
                            }
                            Console.WriteLine();
                            break;
                        case "5":
                            Console.WriteLine(employeeAge.Average());
                            Console.WriteLine();
                            break;
                        case "6":
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Not a valid choice!");
                            Console.WriteLine();
                            break;
                    }
                    }
            
                } while (exit == false);

        }
    }
    }

