﻿//2/24/20
//CSC 153
//Kevin Patterson
//Retail Prices

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            double wholeSale;
            double markupPercent;
            Console.WriteLine("What is the wholesale price: ");
            Double.TryParse(Console.ReadLine(),out wholeSale);
            Console.WriteLine("What is the markup percent:");
            Double.TryParse(Console.ReadLine(), out markupPercent);

            CalculateRetail(wholeSale, markupPercent);
            Console.ReadLine();


        }

        public static double CalculateRetail(double wholeSale, double markupPercent)
        {
            
            double retailPrice = (wholeSale * (markupPercent/100)) + wholeSale;
            Console.WriteLine("The total retail price is:$ " + retailPrice);
            return retailPrice;
        }

    }
    
}
