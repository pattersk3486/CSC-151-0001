﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class StandardMessages
    { public static string DisplayMainMenu()
        {
            return "1.Create Car\n2.Acceleration\n3.Year\n4.Exit";

        }
        public static void Default()
        {
            Console.WriteLine("Not a valid choice!!");
        }
        //public static string AskForYear()
        //{
            //return 
        //}

    }
}
