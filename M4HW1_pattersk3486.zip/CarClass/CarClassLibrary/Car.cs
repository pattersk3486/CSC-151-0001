﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class Car
    { 
        //Fields
        private string _make;
        private string _year;
        private int _speed;

        //Constructor
        public Car()
        {
            Make = "";
            Year = "";
            Speed = 0;

        }
        public Car(string make, string year)
        {
            Make = make;
            Year = year;
            Speed = 0;
        }

        //Properties
        public string Make
        {
            get
            {
                return _make;
            }
            set
            {
                _make = value;
            }
        }
        public string Year
        {
            get
            {
                return _year;
            }
            set
            {
                _year = value;
            }
        }
        public int Speed
        {
            get
            {
                return _speed;
            }
            set
            {
                _speed = value;
            }
        }


        //Methods
        public void Accelerate()
        {
            Speed += 5;
        }
        public void Break()
        {
            if (Speed < 5)
            {
                Console.WriteLine("Can't Brake");
            }
            else
            {
                Speed -= 5;
            }
        }
    }
}
